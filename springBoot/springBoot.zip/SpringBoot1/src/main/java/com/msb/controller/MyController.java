package com.msb.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

/**
 * @author mayang
 */
/*@Controller*/
 @RestController
public class MyController {

    @RequestMapping("/show")
/*    @ResponseBody*/
    public String show() {
        int i= 5/0;
        return "hello";
    }
}
