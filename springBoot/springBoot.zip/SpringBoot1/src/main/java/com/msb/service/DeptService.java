package com.msb.service;

import com.msb.pojo.Dept;

import java.util.List;

/**
 * @author mayang
 */
public interface DeptService {

    List<Dept> findAll();
}
