package com.msb.mapper;

import com.msb.pojo.Dept;

import java.util.List;

/**
 * @author mayang
 */
public interface DeptMapper {

    List<Dept> selectAll();


}
