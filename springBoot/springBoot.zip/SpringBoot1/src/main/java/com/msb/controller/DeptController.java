package com.msb.controller;

import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.msb.pojo.Dept;
import com.msb.service.DeptService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import javax.servlet.http.HttpSession;
import java.util.List;

/**
 * @author mayang
 */
@Controller
public class DeptController {
    @Autowired
    private DeptService deptService;

    public DeptService getDeptService() {
        return deptService;
    }

    public void setDeptService(DeptService deptService) {
        this.deptService = deptService;
    }

/*
    @RequestMapping("/getall")
    @ResponseBody
    public List<Dept> getall(){

        return deptService.findAll();
    }*/

    @RequestMapping("/getall")
    public ModelAndView getall(HttpSession session){
        ModelAndView mv=new ModelAndView();
        mv.addObject("list",deptService.findAll());
        mv.addObject("str","张三");
        mv.setViewName("show");
        session.setAttribute("dept","开发组");
        return mv;
    }

   @RequestMapping("/req")
    public void show(int id,String name){
        System.out.println(id+";"+name);
   }


   @RequestMapping("/showpage")
   public ModelAndView showpage(Integer pageindex){
       ModelAndView mv=new ModelAndView();
        //开启分页
       if(null==pageindex){
           PageHelper.startPage(1,2);
       }else{
           PageHelper.startPage(pageindex,2);
       }
       List<Dept> list=deptService.findAll();
       PageInfo<Dept> pageinfo=new PageInfo<Dept>(list);
       mv.addObject("pageinfo",pageinfo);
       return mv;
   }

/*

  @ExceptionHandler(Exception.class)
   @ResponseBody
   public String showEx(){
        return "请稍等，稍后会有工作人员联系您！";

   }
*/



}
