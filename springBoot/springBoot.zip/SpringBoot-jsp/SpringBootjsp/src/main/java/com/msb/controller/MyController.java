package com.msb.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import java.util.ArrayList;
import java.util.List;

@Controller
public class MyController {

    @RequestMapping("/show")
    public ModelAndView show(){
        ModelAndView modelAndView=new ModelAndView();
        List<String> list=new ArrayList<String>();
        list.add("沈阳");
        list.add("长春");
        list.add("北京");
        list.add("大连");
        list.add("天津");
        modelAndView.addObject("list",list);
        modelAndView.setViewName("show");
        return modelAndView;

    }

    @RequestMapping("/aaa")
    public String aaa(){
        return "aa";
    }

}
