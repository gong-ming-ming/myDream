package com.msb.config;

import com.msb.interCeptor.MyInterCeptor;
import com.msb.pojo.Person;
import com.msb.pojo.User;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.InterceptorRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

/**
 * @author mayang
 */
@Configuration
public class MyConfig implements WebMvcConfigurer  {

    @Bean  //创建bean对象
    protected User userid1(){
        User user=new User();
        user.setId(101);
        user.setName("张三");
        return user;

    }

    @Bean  //创建bean对象
    protected User userid2(){
        User user=new User();
        user.setId(102);
        user.setName("李四");
        return user;

    }

    @Bean
    protected Person personid1(){

        Person person=new Person();
        person.setPid(111);
        person.setUser(userid2());
        return person;
    }

    @Bean
    protected Person personid2(User userid1){

        Person person=new Person();
        person.setPid(112);
        person.setUser(userid1);
        return person;
    }

    @Autowired
    private MyInterCeptor myInterCeptor;

    public MyInterCeptor getMyInterCeptor() {
        return myInterCeptor;
    }

    public void setMyInterCeptor(MyInterCeptor myInterCeptor) {
        this.myInterCeptor = myInterCeptor;
    }

    //配置拦截器的拦截地址映射。
    public void addInterceptors(InterceptorRegistry registry) {
        registry.addInterceptor(myInterCeptor).addPathPatterns("/**").excludePathPatterns("/login");

    }

}
