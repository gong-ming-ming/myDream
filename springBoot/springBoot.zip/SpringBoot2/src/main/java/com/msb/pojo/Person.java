package com.msb.pojo;

/**
 * @author mayang
 */
public class Person {
    private int pid;
    private User user;

    public int getPid() {
        return pid;
    }

    public void setPid(int pid) {
        this.pid = pid;
    }

    public User getUser() {
        return user;
    }

    public void setUser(User user) {
        this.user = user;
    }

    @Override
    public String toString() {
        return "Person{" +
                "pid=" + pid +
                ", user=" + user +
                '}';
    }
}
