public interface TestInterface {
    /*default void eat(){

    }*/
}
