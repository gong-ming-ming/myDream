# Nacos集群配置

 

## 更改Nacos启动命令配置原理

​	我们现在知道，想要启动Naocs只需要启动startup.sh命令即可，但是如果启动3个Nacos那？所以如果我们需要启动多个Nacos，就需要自行修改startup命令。

![image-20210928192937936](image-20210928192937936.png)

## 具体配置



### Linux服务器上MySql数据库配置

1. 在Linux系统上执行SQL脚本，具体位置在nacos目录下的conf中，这里的操作和之前是一样的，我们可以直接打开这个文件然后拷贝到数据库中执行，当然也是要创建数据库使用数据库然后在复制脚本内容，执行即可

```java
create database nacos_config;
use nacos_config;
```

![image-20210929175710498](image-20210929175710498.png)

2. 修改application.properties配置文件，但是修改之前我们最好做一个备份。

```java
cp application.properties application.properties.init
```

3. 这里的修改和我们之间的在win上的修改是完全一样的，所以我们只要打开这个文件，加上对应的内容即可

```java
spring.datasource.platform=mysql

db.num=1
db.url.0=jdbc:mysql://127.0.0.1:3306/nacos_config?characterEncoding=utf8&connectTimeout=1000&socketTimeout=3000&autoReconnect=true&serverTimezone=UTC
db.user=root
db.password=123456
```



### Linux服务器上Nacos的集群配置cluter.conf

1. 这里开始正式配置集群，首先我们要更改cluter.conf这个配置文件，当然我们也需要备份，但是这里它的原始名称为：cluster.conf.example，我们需要把它保留同时复制出一个cluster.conf来进行更改

```java
cp cluster.conf.example cluster.conf
```

![image-20210929182825202](image-20210929182825202.png)

2. 具体配置内容，这里我们在配置集群的时候不能直接写127.0.0.1这样，这样分不清楚，所以我们需要知道具体的IP地址，我们可以通过：

```java
ifconfig -a #查看具体ip	
```

![image-20210929183717870](image-20210929183717870.png)	

具体需修改内容

```java
# 格式： ip地址:端口号
#
# Copyright 1999-2018 Alibaba Group Holding Ltd.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#      http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
#

#it is ip
#example
#192.168.16.101:8847
#192.168.16.102
#192.168.16.10
192.168.124.133:3333
192.168.124.133:4444
192.168.124.133:5555
```

### 编辑Nacos的启动脚本startup.sh

1. 编辑这个脚本的目的，是为了能够让我们在使用此命令启动的时候传入对应的端口号参数，这样携带着具体端口号参数的启动就能启动具体的Nacos节点了，此脚本的为止在/nacos/bin中

![image-20210929184656503](image-20210929184656503.png)

2. 核心点：传递不同的端口号启动不同的nacos实例，命令：./startup.sh -p 3333表示启动端口号为3333的nacos服务器实例，这里要和config保持一直。

3. 具体修改，依旧要备份：

```java
cp startup.sh starup.sh.bk
```

![image-20210929191829619](image-20210929191829619.png)

![image-20210930140906685](image-20210929192905262.png)

### Nginx配置

1. 我们需要找到Nginx的配置文件，然后做备份

```java
cd /usr/local/nginx
cp nginx.conf nginx.conf.bk
```

![image-20210929211042606](image-20210929211042606.png)

2. 修改nginx.conf

![image-20210930175441230](image-20210929211759169.png)



## 测试启动



### 启动Nacos

1. 这里注意，我们在启动之前必须要保证JDK环境变量配置好，同时保证以上配置没有问题，具体启动命令：

   ./stratup.sh -o 3333/4444/5555

```java
[root@localhost bin]# ./startup.sh -o 3333
[root@localhost bin]# ./startup.sh -o 4444
[root@localhost bin]# ./startup.sh -o 5555
```

![image-20210930143609552](image-20210930141259794.png)

2. 启动完成之后我们需要通过如下指令来测试Nacos集群是否正常启动，数量为3

```java
ps -ef|grep nacos|grep -v grep |wc -l
```

![image-20210930143912889](image-20210930143912889.png)



### 启动Nginx

1. 首先进入到Nginx目录下，启动Nginx，同时要带着我们设置过得配置文件启动

```java
cd /usr/local/nginx/sbin
./nginx -c /usr/local/nginx/conf/nginx.conf
```

2. 通过访问Nginx来测试是否能够访问到Nacos，在win系统浏览器网址上输入：

```java
192.168.124.133:1111/nacos
```

![image-20210930150017223](image-20210930150017223.png)

3. 使用账号密码nacos，nacos成功登录就表示此时已经完成全部配置

![image-20210930153201511](image-20210930153201511.png)



### 添加配置

1. 在Nacos平台上添加配置

![image-20210930153148673](image-20210930153148673.png)

2. 在数据库中检查是否有这一条配置，如果有表示成功添加

![image-20210930153709605](image-20210930153709605.png)

### 配置微服务为Linux版Nacos集群并注册进Nacos

1. 我们以9002为例，此时我们要修改application.yaml文件，把之前的Nacos端口换成Nacos集群

```java
server:
  port: 9002
spring:
  application:
    name: nacos-provider
  cloud:
    nacos:
      discovery:
        # server-addr: localhost:8848
        # 换成nginx的1111端口，做集群
        server-addr: http://192.168.124.133:1111


management:
  endpoint:
    web:
      exponsure:
        include: '*'

```

2. 配置完成启动服务，我们就可以在Naocs平台上看见对应的微服务了，此时表示服务注册成功

![image-20210930155527834](image-20210930155527834.png)



### 总结

![image-20210930160340892](image-20210930160158834.png)

