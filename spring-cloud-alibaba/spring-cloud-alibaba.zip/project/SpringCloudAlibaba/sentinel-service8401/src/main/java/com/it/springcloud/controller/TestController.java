package com.it.springcloud.controller;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.it.springcloud.service.TestService;

@RestController
@RequestMapping("/test")
public class TestController {
	
	@Autowired
	private TestService testService;
	
	@RequestMapping("/testA")
	public String testA() {
		System.out.println(Thread.currentThread().getName()+"testA");
		
		return testService.common();
	}
	
	@RequestMapping("/testB")
	public String testB() {
//		try {
//			//每次修改重启都要重新创建流控规则
//			Thread.sleep(5000);
//		} catch (InterruptedException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}
		return testService.common();
	}

}
