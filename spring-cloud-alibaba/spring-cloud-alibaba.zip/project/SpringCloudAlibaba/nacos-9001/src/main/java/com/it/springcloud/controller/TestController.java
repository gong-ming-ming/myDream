package com.it.springcloud.controller;

import java.util.HashMap;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.it.springcloud.entity.JsonResult;

@RestController
@RequestMapping(value = "test")
public class TestController {
	
	@Value("${server.port}")
	private String port;

	@GetMapping("/hello")
	public String test() {
		return "hello world! prot:" + port;
	}	
	
	
	//模仿数据库存储数据
    public static HashMap<Long,String> hashMap = new HashMap<>();
    static {
        hashMap.put(1l,"鼠标");
        hashMap.put(2l,"键盘");
        hashMap.put(3l,"耳机");
    }

    @GetMapping("info/{id}")
    public JsonResult<String> msbSql(@PathVariable("id") Long id){
        JsonResult<String> result = new JsonResult(200,"port:" + port + ":" + hashMap.get(id));
        return result;
    }
}
