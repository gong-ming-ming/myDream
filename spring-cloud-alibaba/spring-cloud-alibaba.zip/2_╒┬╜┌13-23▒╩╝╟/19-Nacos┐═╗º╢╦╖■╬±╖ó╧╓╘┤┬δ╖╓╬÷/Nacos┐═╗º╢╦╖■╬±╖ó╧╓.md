# Nacos客户端服务发现源码分析

## 总体流程	

首先我们先通过一个图来直观的看一下，Nacos客户端的服务发现，其实就是封装参数、调用服务接口、获得返回实例列表。

![image-20211022150934273](image-20211022150934273.png)

​	但是如果我们要是细化这个流程，会发现不仅包括了通过NamingService获取服务列表，在获取服务列表的过程中还涉及到通信流程协议（Http or gPRC）、订阅流程、故障转移流程等。下面我们来详细的捋一捋。

​	入口，其实这个入口我们在之前看过，就在NamingTest中可以看到：

```java
public class NamingTest {
    
    @Test
    public void testServiceList() throws Exception {
   	......
    
        NamingService namingService = NacosFactory.createNamingService(properties);
        namingService.registerInstance("nacos.test.1", instance);
        
        ThreadUtils.sleep(5000L);
        
        List<Instance> list = namingService.getAllInstances("nacos.test.1");
        
        System.out.println(list);
        
    }
}
```

​	在这里我们主要要关注getAllInstances方法，那我们就需要看一下这个方法的具体操作，当然这其中需要经过一系列的重载方法调用

​	其实这里的方法比入口多出了几个参数，这里不仅有服务名称，还有分组名、集群列表、是否订阅，重载方法中的其他参数已经在各种重载方法的调用过程中设置了默认值，比如：

​	分组名称默认：DEFAULT_GROUOP

​	集群列表：默认为空数组

​	是否订阅：订阅

```java
@Override
public List<Instance> getAllInstances(String serviceName, String groupName, List<String> clusters,
                                      boolean subscribe) throws NacosException {
    ServiceInfo serviceInfo;
    String clusterString = StringUtils.join(clusters, ",");
    // 是否是订阅模式
    if (subscribe) {
        // 先从客户端缓存获取服务信息
        serviceInfo = serviceInfoHolder.getServiceInfo(serviceName,  , clusterString);
        if (null == serviceInfo) {
            // 如果本地缓存不存在服务信息，则进行订阅
            serviceInfo = clientProxy.subscribe(serviceName, groupName, clusterString);
        }
    } else {
        // 如果未订阅服务信息，则直接从服务器进行查询
        serviceInfo = clientProxy.queryInstancesOfService(serviceName, groupName, clusterString, 0, false);
    }
    // 从服务信息中获取实例列表
    List<Instance> list;
    if (serviceInfo == null || CollectionUtils.isEmpty(list = serviceInfo.getHosts())) {
        return new ArrayList<Instance>();
    }
    return list;
}
```

​	此方法的流程图：

![image-20211022171827857](image-20211022171827857.png)



​	这个流程基本逻辑为：

​		如果是订阅模式，则直接从本地缓存获取服务信息(ServiceInfo)，然后从中获取实例列表，这是因为订阅机制会自动同步服务器实例的变化到本地。如果本地缓存中没有，那说明是首次调用，则进行订阅，在订阅完成后会获得服务信息。

​		如果是非订阅模式，那就直接请求服务器端，获得服务信息。

## 订阅处理流程

​	在刚才的流程中，涉及到了订阅的逻辑，入口代码为获取实例列表中的方法：

```java
serviceInfo = clientProxy.subscribe(serviceName, groupName, clusterString);
```

​	以下是具体分析。首先这里的clientProxy是NamingClientProxy类的对象，对应的实现类是NamingClientProxyDelegate对应subscribe实现如下：

```java
@Override
public ServiceInfo subscribe(String serviceName, String groupName, String clusters) throws NacosException {
    String serviceNameWithGroup = NamingUtils.getGroupedName(serviceName, groupName);
    String serviceKey = ServiceInfo.getKey(serviceNameWithGroup, clusters);
    // 定时调度UpdateTask
    serviceInfoUpdateService.scheduleUpdateIfAbsent(serviceName, groupName, clusters);
    // 获取缓存中的ServiceInfo
    ServiceInfo result = serviceInfoHolder.getServiceInfoMap().get(serviceKey);
    if (null == result) {
        // 如果为null，则进行订阅逻辑处理，基于gRPC协议
        result = grpcClientProxy.subscribe(serviceName, groupName, clusters);
    }
    // ServiceInfo本地缓存处理
    serviceInfoHolder.processServiceInfo(result);
    return result;
}
```

​	在这段代码中，可以看到在获取服务实例列表时（特别是首次），也进行了订阅逻辑的拓展，基本流程图如下：

![image-20211025155023146](image-20211025155023146.png)

​	具体流程分析：

	1. 订阅方法先开启定时任务，这个定时任务的主要作用就是用来定时同步服务端的实例信息，并进行本地缓存更新等操作，但是如果是首次这里将会直接返回来走下一步。
 	2. 判断本地缓存是否存在，如果本地缓存存在ServiceInfo信息，则直接返回。如果不存在，则默认采用gRPC协议进行订阅，并返回ServiceInfo。
 	3. grpcClientProxy的subscribe订阅方法就是直接向服务器发送了一个订阅请求，并返回结果。
 	4. 最后，ServiceInfo本地缓存处理。这里会将获得的最新ServiceInfo与本地内存中的ServiceInfo进行比较，更新，发布变更时间，磁盘文件存储等操作。其实，这一步的操作，在订阅定时任务中也进行了处理。

