package com.mashibing.mapper;

import com.mashibing.bean.Emp;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 *  Mapper 接口
 * </p>
 *
 * @author lian
 * @since 2020-04-04
 */
public interface EmpMapper extends BaseMapper<Emp> {

}
