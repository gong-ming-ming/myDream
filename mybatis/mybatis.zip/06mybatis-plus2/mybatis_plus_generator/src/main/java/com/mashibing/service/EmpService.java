package com.mashibing.service;

import com.mashibing.bean.Emp;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author lian
 * @since 2020-04-04
 */
public interface EmpService extends IService<Emp> {

}
