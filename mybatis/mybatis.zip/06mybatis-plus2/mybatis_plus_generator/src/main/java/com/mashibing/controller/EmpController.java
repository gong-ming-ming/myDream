package com.mashibing.controller;


import org.springframework.web.bind.annotation.RequestMapping;

import org.springframework.stereotype.Controller;

/**
 * <p>
 *  前端控制器
 * </p>
 *
 * @author lian
 * @since 2020-04-04
 */
@Controller
@RequestMapping("/emp")
public class EmpController {

}

