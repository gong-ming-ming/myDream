package com.mashibing.bean;

import java.util.Date;
import javax.annotation.Generated;

public class Emp {
    @Generated(value="org.mybatis.generator.api.MyBatisGenerator", date="2020-03-29T21:11:27.86+08:00", comments="Source field: emp.EMPNO")
    private Integer empno;

    @Generated(value="org.mybatis.generator.api.MyBatisGenerator", date="2020-03-29T21:11:27.868+08:00", comments="Source field: emp.ENAME")
    private String ename;

    @Generated(value="org.mybatis.generator.api.MyBatisGenerator", date="2020-03-29T21:11:27.868+08:00", comments="Source field: emp.JOB")
    private String job;

    @Generated(value="org.mybatis.generator.api.MyBatisGenerator", date="2020-03-29T21:11:27.868+08:00", comments="Source field: emp.MGR")
    private Integer mgr;

    @Generated(value="org.mybatis.generator.api.MyBatisGenerator", date="2020-03-29T21:11:27.869+08:00", comments="Source field: emp.HIREDATE")
    private Date hiredate;

    @Generated(value="org.mybatis.generator.api.MyBatisGenerator", date="2020-03-29T21:11:27.869+08:00", comments="Source field: emp.SAL")
    private Double sal;

    @Generated(value="org.mybatis.generator.api.MyBatisGenerator", date="2020-03-29T21:11:27.869+08:00", comments="Source field: emp.COMM")
    private Double comm;

    @Generated(value="org.mybatis.generator.api.MyBatisGenerator", date="2020-03-29T21:11:27.869+08:00", comments="Source field: emp.DEPTNO")
    private Integer deptno;

    @Generated(value="org.mybatis.generator.api.MyBatisGenerator", date="2020-03-29T21:11:27.867+08:00", comments="Source field: emp.EMPNO")
    public Integer getEmpno() {
        return empno;
    }

    @Generated(value="org.mybatis.generator.api.MyBatisGenerator", date="2020-03-29T21:11:27.868+08:00", comments="Source field: emp.EMPNO")
    public void setEmpno(Integer empno) {
        this.empno = empno;
    }

    @Generated(value="org.mybatis.generator.api.MyBatisGenerator", date="2020-03-29T21:11:27.868+08:00", comments="Source field: emp.ENAME")
    public String getEname() {
        return ename;
    }

    @Generated(value="org.mybatis.generator.api.MyBatisGenerator", date="2020-03-29T21:11:27.868+08:00", comments="Source field: emp.ENAME")
    public void setEname(String ename) {
        this.ename = ename;
    }

    @Generated(value="org.mybatis.generator.api.MyBatisGenerator", date="2020-03-29T21:11:27.868+08:00", comments="Source field: emp.JOB")
    public String getJob() {
        return job;
    }

    @Generated(value="org.mybatis.generator.api.MyBatisGenerator", date="2020-03-29T21:11:27.868+08:00", comments="Source field: emp.JOB")
    public void setJob(String job) {
        this.job = job;
    }

    @Generated(value="org.mybatis.generator.api.MyBatisGenerator", date="2020-03-29T21:11:27.868+08:00", comments="Source field: emp.MGR")
    public Integer getMgr() {
        return mgr;
    }

    @Generated(value="org.mybatis.generator.api.MyBatisGenerator", date="2020-03-29T21:11:27.868+08:00", comments="Source field: emp.MGR")
    public void setMgr(Integer mgr) {
        this.mgr = mgr;
    }

    @Generated(value="org.mybatis.generator.api.MyBatisGenerator", date="2020-03-29T21:11:27.869+08:00", comments="Source field: emp.HIREDATE")
    public Date getHiredate() {
        return hiredate;
    }

    @Generated(value="org.mybatis.generator.api.MyBatisGenerator", date="2020-03-29T21:11:27.869+08:00", comments="Source field: emp.HIREDATE")
    public void setHiredate(Date hiredate) {
        this.hiredate = hiredate;
    }

    @Generated(value="org.mybatis.generator.api.MyBatisGenerator", date="2020-03-29T21:11:27.869+08:00", comments="Source field: emp.SAL")
    public Double getSal() {
        return sal;
    }

    @Generated(value="org.mybatis.generator.api.MyBatisGenerator", date="2020-03-29T21:11:27.869+08:00", comments="Source field: emp.SAL")
    public void setSal(Double sal) {
        this.sal = sal;
    }

    @Generated(value="org.mybatis.generator.api.MyBatisGenerator", date="2020-03-29T21:11:27.869+08:00", comments="Source field: emp.COMM")
    public Double getComm() {
        return comm;
    }

    @Generated(value="org.mybatis.generator.api.MyBatisGenerator", date="2020-03-29T21:11:27.869+08:00", comments="Source field: emp.COMM")
    public void setComm(Double comm) {
        this.comm = comm;
    }

    @Generated(value="org.mybatis.generator.api.MyBatisGenerator", date="2020-03-29T21:11:27.87+08:00", comments="Source field: emp.DEPTNO")
    public Integer getDeptno() {
        return deptno;
    }

    @Generated(value="org.mybatis.generator.api.MyBatisGenerator", date="2020-03-29T21:11:27.87+08:00", comments="Source field: emp.DEPTNO")
    public void setDeptno(Integer deptno) {
        this.deptno = deptno;
    }
}